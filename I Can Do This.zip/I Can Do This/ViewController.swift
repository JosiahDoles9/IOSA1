import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var dogImageView: UIImageView!

    var isDogImageDisplayed = true

    override func viewDidLoad() {

        super.viewDidLoad()
        dogImageView.image = UIImage(named: "dog")
    }

    @IBAction func toggleButtonTapped(_ sender: Any) {
        if isDogImageDisplayed {

            dogImageView.image = UIImage(named: "cat")
        } else {
            dogImageView.image = UIImage(named: "dog")
        }
        isDogImageDisplayed = !isDogImageDisplayed

    }

}

